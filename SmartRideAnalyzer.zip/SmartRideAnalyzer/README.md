# Smart Ride Analyzer — Android Project

A real Android Studio project (Java, Gradle) that ports the Smart Ride
Analyzer V17 browser prototype into a native app for rideshare drivers who
juggle multiple driver apps (Uber, Ola, Rapido, ...).

**The driver always makes the final accept/decline decision. The app only
analyzes and displays recommendations — it never accepts, declines, or
touches any button inside another app.**

## Opening the project

1. Open Android Studio (Hedgehog / Koala or newer).
2. **File → Open** and select the `SmartRideAnalyzer` folder (the one
   containing `settings.gradle`).
3. Let Gradle sync. Requires:
   - Android Gradle Plugin 8.4.1 (declared in root `build.gradle`)
   - Gradle 8.6 (declared in `gradle/wrapper/gradle-wrapper.properties` —
     Android Studio will download the wrapper jar automatically the first
     time you sync; if it complains about a missing wrapper jar, use
     **File → Sync Project with Gradle Files** or run `gradle wrapper`
     once from a terminal with network access)
   - compileSdk / targetSdk 34, minSdk 26
4. Run on an emulator or device (`Shift+F10` / the green Run button).

## Project layout

```
app/src/main/java/com/smartride/analyzer/
├── MainActivity.java                 UI glue: wires every section together
├── model/
│   └── RideOffer.java                Raw + calculated data for one offer
├── core/
│   ├── DriverSettings.java           Fuel price & mileage (SharedPreferences)
│   ├── RideAnalyzer.java             Fuel cost / net earnings / ₹-per-hour / score
│   ├── RideQueueManager.java         Smart Ride Queue: add, sort, filter, expire
│   ├── CurrentTripManager.java       Current trip state + trip-intelligence text
│   ├── DailyStatistics.java          Running daily totals
│   └── NotificationParser.java       Regex-based offer extraction (future feature)
├── service/
│   ├── RideNotificationListenerService.java   NotificationListenerService (future)
│   └── RideOfferBridge.java          In-memory hand-off from service → UI
└── adapter/
    └── OfferAdapter.java             RecyclerView adapter for the comparison list
```

Resources: `res/layout/activity_main.xml` (single scrolling screen with every
section from the spec), `res/layout/item_offer.xml` (one comparison row),
plus `colors.xml` / `themes.xml` / `strings.xml`.

## What's implemented now (matches V17 logic 1:1)

- Driver Settings (fuel price, mileage) — persisted with SharedPreferences.
- Ride calculation: `totalDistance`, `fuelCost`, `netEarnings`,
  `earningsPerHour` exactly as specified.
- Experimental Ride Score (0–100), clearly labelled as experimental, with the
  same break points as the spec (net earnings, ₹/hour, pickup distance, total
  distance penalty).
- Smart Ride Queue: every offer is timestamped; status is derived live as
  FRESH (<3 min) / EXPIRING (3–5 min) / EXPIRED (≥5 min); expired offers are
  excluded from "Best Current Offer" but stay visible until purged.
- Current Trip + trip-intelligence messaging at the three thresholds
  (>5 min / 2–5 min / ≤2 min remaining).
- Best Current Offer card, Ride Comparison list (app, fare, pickup, distance,
  fuel, net, ₹/hour, score, status), and an AI Ride Assistant panel that
  explains *why* a tapped offer scored the way it did (analysis only — never
  a decision).
- Manual Test Mode with the exact Uber/Ola/Rapido test offers from the spec,
  plus "Add 3 Test Offers" and "Clear Queue".
- Daily Statistics (completed rides, gross/fuel/net, distance, net ₹/hour).

## What's scaffolded for later (not wired into the UI yet)

- **`RideNotificationListenerService`**: declared in the manifest and ready
  to receive `onNotificationPosted()` callbacks once the driver grants
  Notification Access in system settings (Settings → Apps → Special access →
  Notification access → Smart Ride Analyzer). It only *reads* notification
  title/text from Uber/Ola/Rapido — it never dismisses, clicks, or interacts
  with them.
- **`NotificationParser`**: regex patterns for fare / pickup km / trip km /
  minutes. These are starting-point patterns; real notification wording
  differs by app version and will need tuning against actual captured
  notification text. New patterns (or new supported apps) can be added here
  without touching any other class.
- **`RideOfferBridge`**: a simple in-process publish/subscribe singleton so
  the listener service can hand a parsed `RideOffer` to `MainActivity` once
  the parser is production-ready. `MainActivity` already implements
  `RideOfferBridge.Listener`, so turning this on is just a matter of the
  parser reliably producing good offers.
- **Daily statistics persistence** currently uses SharedPreferences keyed by
  date (good enough for daily totals). If full per-ride history is wanted
  later, add a Room entity/DAO (e.g. `RideRecord` / `RideRecordDao`) — the
  `androidx.room` dependencies are already declared in `app/build.gradle`,
  and `DailyStatistics`'s public API is written so the underlying storage can
  be swapped without touching `MainActivity`.

## Design notes / assumptions

- `minSdk 26` was chosen because adaptive launcher icons (used here to avoid
  needing hand-drawn PNGs at every density) require API 26+, and
  `NotificationListenerService` support is solid from API 26 onward. Lower it
  if you need to support older devices — you'd then also need legacy PNG
  mipmap icons.
- The launcher icon is a simple vector (adaptive icon), not a designed logo —
  swap `ic_launcher_foreground.xml` / `ic_launcher_background.xml` for real
  artwork whenever you're ready.
- View Binding is enabled (`buildFeatures.viewBinding true`) instead of
  `findViewById` throughout `MainActivity`.
- I couldn't verify a full Gradle build in this environment (no network
  access here to fetch dependencies), so double-check the first sync in
  Android Studio and let me know if anything needs adjusting.

package com.smartride.analyzer.core;

import android.content.Context;
import android.content.SharedPreferences;

import com.smartride.analyzer.model.RideOffer;

import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Locale;

/**
 * Tracks running daily totals: completed rides, gross earnings, fuel cost,
 * net earnings and total distance, so the driver can see net earnings/hour
 * for the day. Backed by SharedPreferences, keyed by date, which is enough
 * for daily aggregates. If full per-ride history is needed later, swap this
 * for a Room entity/DAO (RideRecord/RideRecordDao) without changing the
 * public API below.
 */
public class DailyStatistics {

    private static final String PREFS_NAME = "smart_ride_daily_stats";

    private final SharedPreferences prefs;
    private final String todayKey;

    public DailyStatistics(Context context) {
        this.prefs = context.getApplicationContext()
                .getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE);
        this.todayKey = new SimpleDateFormat("yyyy-MM-dd", Locale.US).format(new Date());
    }

    /** Call when the driver marks a trip as completed for a given accepted offer. */
    public void recordCompletedRide(RideOffer completedOffer) {
        SharedPreferences.Editor editor = prefs.edit();
        editor.putInt(key("rides"), getCompletedRides() + 1);
        editor.putFloat(key("gross"), (float) (getGrossEarnings() + completedOffer.getFare()));
        editor.putFloat(key("fuel"), (float) (getFuelCost() + completedOffer.getFuelCost()));
        editor.putFloat(key("net"), (float) (getNetEarnings() + completedOffer.getNetEarnings()));
        editor.putFloat(key("distance"), (float) (getTotalDistance() + completedOffer.getTotalDistanceKm()));
        editor.putFloat(key("minutes"), (float) (getTotalMinutes() + completedOffer.getEstimatedTimeMinutes()));
        editor.apply();
    }

    public int getCompletedRides() {
        return prefs.getInt(key("rides"), 0);
    }

    public double getGrossEarnings() {
        return prefs.getFloat(key("gross"), 0f);
    }

    public double getFuelCost() {
        return prefs.getFloat(key("fuel"), 0f);
    }

    public double getNetEarnings() {
        return prefs.getFloat(key("net"), 0f);
    }

    public double getTotalDistance() {
        return prefs.getFloat(key("distance"), 0f);
    }

    private double getTotalMinutes() {
        return prefs.getFloat(key("minutes"), 0f);
    }

    public double getNetEarningsPerHour() {
        double minutes = getTotalMinutes();
        if (minutes <= 0) return 0;
        return getNetEarnings() / (minutes / 60.0);
    }

    public void resetToday() {
        SharedPreferences.Editor editor = prefs.edit();
        editor.remove(key("rides"));
        editor.remove(key("gross"));
        editor.remove(key("fuel"));
        editor.remove(key("net"));
        editor.remove(key("distance"));
        editor.remove(key("minutes"));
        editor.apply();
    }

    private String key(String field) {
        return todayKey + "_" + field;
    }
}

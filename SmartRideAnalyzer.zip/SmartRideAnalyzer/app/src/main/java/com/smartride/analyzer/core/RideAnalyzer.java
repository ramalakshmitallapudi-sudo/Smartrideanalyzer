package com.smartride.analyzer.core;

import com.smartride.analyzer.model.RideOffer;

import java.util.ArrayList;
import java.util.List;

/**
 * Pure calculation engine. Computes fuel cost, net earnings, earnings/hour and
 * an EXPERIMENTAL ride score for a single offer, given the driver's fuel price
 * and vehicle mileage. This class never accepts/declines rides — it only scores them.
 */
public class RideAnalyzer {

    private final float fuelPricePerLitre;
    private final float vehicleMileage;

    public RideAnalyzer(float fuelPricePerLitre, float vehicleMileage) {
        this.fuelPricePerLitre = fuelPricePerLitre;
        this.vehicleMileage = vehicleMileage;
    }

    /** Runs all calculations and mutates the offer's derived fields in place. */
    public void analyze(RideOffer offer) {
        double totalDistance = offer.getPickupDistanceKm() + offer.getPassengerDistanceKm();

        double fuelCost = 0;
        if (vehicleMileage > 0) {
            fuelCost = (totalDistance / vehicleMileage) * fuelPricePerLitre;
        }

        double netEarnings = offer.getFare() - fuelCost;

        double earningsPerHour = 0;
        if (offer.getEstimatedTimeMinutes() > 0) {
            earningsPerHour = netEarnings / (offer.getEstimatedTimeMinutes() / 60.0);
        }

        offer.setTotalDistanceKm(totalDistance);
        offer.setFuelCost(fuelCost);
        offer.setNetEarnings(netEarnings);
        offer.setEarningsPerHour(earningsPerHour);

        List<String> reasons = new ArrayList<>();
        int score = 50;

        // Net earnings
        if (netEarnings >= 300) {
            score += 20;
            reasons.add("Strong net earnings (₹" + round(netEarnings) + ")");
        } else if (netEarnings >= 200) {
            score += 12;
            reasons.add("Good net earnings (₹" + round(netEarnings) + ")");
        } else if (netEarnings >= 100) {
            score += 5;
            reasons.add("Moderate net earnings (₹" + round(netEarnings) + ")");
        } else {
            score -= 15;
            reasons.add("Low net earnings (₹" + round(netEarnings) + ")");
        }

        // Earnings per hour
        if (earningsPerHour >= 500) {
            score += 20;
            reasons.add("Strong earnings per hour (₹" + round(earningsPerHour) + "/hr)");
        } else if (earningsPerHour >= 350) {
            score += 12;
            reasons.add("Good earnings per hour (₹" + round(earningsPerHour) + "/hr)");
        } else if (earningsPerHour >= 200) {
            score += 5;
            reasons.add("Moderate earnings per hour (₹" + round(earningsPerHour) + "/hr)");
        } else {
            score -= 10;
            reasons.add("Low earnings per hour (₹" + round(earningsPerHour) + "/hr)");
        }

        // Pickup distance
        double pickup = offer.getPickupDistanceKm();
        if (pickup <= 1) {
            score += 10;
            reasons.add("Very short pickup distance (" + round(pickup) + " km)");
        } else if (pickup <= 3) {
            score += 5;
            reasons.add("Reasonable pickup distance (" + round(pickup) + " km)");
        } else {
            score -= 5;
            reasons.add("Long pickup distance (" + round(pickup) + " km)");
        }

        // Total distance penalty
        if (totalDistance > 25) {
            score -= 8;
            reasons.add("Long total distance (" + round(totalDistance) + " km)");
        }

        // Clamp 0-100
        if (score > 100) score = 100;
        if (score < 0) score = 0;

        offer.setScore(score);
        offer.setScoreReasons(reasons.toArray(new String[0]));
    }

    /** Analyzes every offer in the list in place. */
    public void analyzeAll(List<RideOffer> offers) {
        for (RideOffer offer : offers) {
            analyze(offer);
        }
    }

    private double round(double value) {
        return Math.round(value * 10.0) / 10.0;
    }
}

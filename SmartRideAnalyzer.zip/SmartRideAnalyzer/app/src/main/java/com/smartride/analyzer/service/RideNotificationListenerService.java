package com.smartride.analyzer.service;

import android.app.Notification;
import android.os.Bundle;
import android.service.notification.NotificationListenerService;
import android.service.notification.StatusBarNotification;
import android.util.Log;

import com.smartride.analyzer.core.NotificationParser;
import com.smartride.analyzer.model.RideOffer;

/**
 * FUTURE FEATURE — not wired into the UI yet.
 *
 * Once the driver explicitly grants Notification Access (Settings > Apps >
 * Special access > Notification access), Android will route notifications
 * from every app, including Uber/Ola/Rapido, through onNotificationPosted().
 *
 * This service:
 *   1. Reads the notification's package name + text (title/body).
 *   2. Hands it to NotificationParser to see if it's a recognizable ride offer.
 *   3. If parsed successfully, forwards the resulting RideOffer to the app's
 *      in-memory bridge so MainActivity/RideQueueManager can pick it up.
 *
 * It NEVER calls cancelNotification(), NEVER performs a notification action,
 * and NEVER interacts with Uber/Ola/Rapido in any way — it only reads text.
 */
public class RideNotificationListenerService extends NotificationListenerService {

    private static final String TAG = "RideNotificationListener";

    private final NotificationParser parser = new NotificationParser();

    @Override
    public void onNotificationPosted(StatusBarNotification sbn) {
        super.onNotificationPosted(sbn);

        if (sbn == null || sbn.getNotification() == null) return;

        String packageName = sbn.getPackageName();

        // Fast bail-out: ignore anything that isn't a supported ride app.
        if (parser.identifyApp(packageName) == null) {
            return;
        }

        String text = extractNotificationText(sbn.getNotification());
        if (text == null || text.isEmpty()) {
            return;
        }

        RideOffer offer = parser.parse(packageName, text, sbn.getPostTime());
        if (offer != null) {
            Log.d(TAG, "Parsed ride offer from " + offer.getAppLabel()
                    + " — fare ₹" + offer.getFare());
            RideOfferBridge.getInstance().publishOffer(offer);
        } else {
            Log.d(TAG, "Notification from " + packageName
                    + " did not match a known ride-offer pattern.");
        }
    }

    @Override
    public void onNotificationRemoved(StatusBarNotification sbn) {
        super.onNotificationRemoved(sbn);
        // Intentionally no-op: a removed notification does not mean the
        // offer is gone from the driver's other app; the queue's own
        // FRESH/EXPIRING/EXPIRED timer governs offer lifetime.
    }

    private String extractNotificationText(Notification notification) {
        Bundle extras = notification.extras;
        if (extras == null) return null;

        StringBuilder combined = new StringBuilder();

        CharSequence title = extras.getCharSequence(Notification.EXTRA_TITLE);
        CharSequence text = extras.getCharSequence(Notification.EXTRA_TEXT);
        CharSequence bigText = extras.getCharSequence(Notification.EXTRA_BIG_TEXT);

        if (title != null) combined.append(title).append(" ");
        if (bigText != null) {
            combined.append(bigText);
        } else if (text != null) {
            combined.append(text);
        }

        return combined.toString().trim();
    }
}

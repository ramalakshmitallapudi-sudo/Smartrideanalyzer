package com.smartride.analyzer.core;

import android.content.Context;
import android.content.SharedPreferences;

/**
 * Persists driver-configurable settings (fuel price, vehicle mileage) using
 * SharedPreferences. Simple key/value settings — no Room needed here.
 */
public class DriverSettings {

    private static final String PREFS_NAME = "smart_ride_driver_settings";
    private static final String KEY_FUEL_PRICE = "fuel_price_per_litre";
    private static final String KEY_MILEAGE = "vehicle_mileage_km_per_litre";

    // Sensible defaults so calculations never divide by zero before setup.
    private static final float DEFAULT_FUEL_PRICE = 100f;   // ₹ per litre
    private static final float DEFAULT_MILEAGE = 15f;       // km per litre

    private final SharedPreferences prefs;

    public DriverSettings(Context context) {
        this.prefs = context.getApplicationContext()
                .getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE);
    }

    public float getFuelPricePerLitre() {
        return prefs.getFloat(KEY_FUEL_PRICE, DEFAULT_FUEL_PRICE);
    }

    public void setFuelPricePerLitre(float value) {
        prefs.edit().putFloat(KEY_FUEL_PRICE, value).apply();
    }

    public float getVehicleMileage() {
        return prefs.getFloat(KEY_MILEAGE, DEFAULT_MILEAGE);
    }

    public void setVehicleMileage(float value) {
        prefs.edit().putFloat(KEY_MILEAGE, value).apply();
    }

    public boolean isConfigured() {
        return prefs.contains(KEY_FUEL_PRICE) && prefs.contains(KEY_MILEAGE);
    }
}

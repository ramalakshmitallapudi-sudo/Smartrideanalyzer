package com.smartride.analyzer.adapter;

import android.graphics.Color;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import com.smartride.analyzer.R;
import com.smartride.analyzer.model.RideOffer;

import java.util.ArrayList;
import java.util.List;
import java.util.Locale;

/**
 * Displays the Ride Comparison table / Smart Ride Queue list.
 * Each row shows app, fare, pickup, total distance, fuel, net, ₹/hour,
 * score and status — matching the comparison columns in the spec.
 */
public class OfferAdapter extends RecyclerView.Adapter<OfferAdapter.OfferViewHolder> {

    public interface OnOfferClickListener {
        void onOfferClicked(RideOffer offer);
    }

    private final List<RideOffer> offers = new ArrayList<>();
    private final OnOfferClickListener clickListener;

    public OfferAdapter(OnOfferClickListener clickListener) {
        this.clickListener = clickListener;
    }

    public void submitList(List<RideOffer> newOffers) {
        offers.clear();
        offers.addAll(newOffers);
        notifyDataSetChanged();
    }

    @NonNull
    @Override
    public OfferViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(parent.getContext())
                .inflate(R.layout.item_offer, parent, false);
        return new OfferViewHolder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull OfferViewHolder holder, int position) {
        RideOffer offer = offers.get(position);
        long now = System.currentTimeMillis();

        holder.appName.setText(offer.getAppLabel());
        holder.fare.setText(formatRupees(offer.getFare()));
        holder.pickup.setText(String.format(Locale.US, "%.1f km", offer.getPickupDistanceKm()));
        holder.distance.setText(String.format(Locale.US, "%.1f km", offer.getTotalDistanceKm()));
        holder.fuel.setText(formatRupees(offer.getFuelCost()));
        holder.net.setText(formatRupees(offer.getNetEarnings()));
        holder.perHour.setText(formatRupees(offer.getEarningsPerHour()) + "/hr");
        holder.score.setText(String.valueOf(offer.getScore()));

        RideOffer.OfferStatus status = offer.getStatus(now);
        holder.status.setText(statusLabel(status));
        holder.status.setTextColor(statusColor(status));
        holder.scoreCircle.setText(String.valueOf(offer.getScore()));
        holder.scoreCircle.setBackgroundColor(scoreColor(offer.getScore()));

        holder.itemView.setOnClickListener(v -> {
            if (clickListener != null) clickListener.onOfferClicked(offer);
        });
    }

    @Override
    public int getItemCount() {
        return offers.size();
    }

    private String formatRupees(double value) {
        return "₹" + String.format(Locale.US, "%.0f", value);
    }

    private String statusLabel(RideOffer.OfferStatus status) {
        switch (status) {
            case FRESH: return "FRESH";
            case EXPIRING: return "EXPIRING";
            default: return "EXPIRED";
        }
    }

    private int statusColor(RideOffer.OfferStatus status) {
        switch (status) {
            case FRESH: return Color.parseColor("#2E7D32");
            case EXPIRING: return Color.parseColor("#F9A825");
            default: return Color.parseColor("#9E9E9E");
        }
    }

    private int scoreColor(int score) {
        if (score >= 70) return Color.parseColor("#2E7D32");
        if (score >= 45) return Color.parseColor("#F9A825");
        return Color.parseColor("#C62828");
    }

    static class OfferViewHolder extends RecyclerView.ViewHolder {
        TextView appName, fare, pickup, distance, fuel, net, perHour, score, status, scoreCircle;

        OfferViewHolder(@NonNull View itemView) {
            super(itemView);
            appName = itemView.findViewById(R.id.text_app_name);
            fare = itemView.findViewById(R.id.text_fare);
            pickup = itemView.findViewById(R.id.text_pickup);
            distance = itemView.findViewById(R.id.text_distance);
            fuel = itemView.findViewById(R.id.text_fuel);
            net = itemView.findViewById(R.id.text_net);
            perHour = itemView.findViewById(R.id.text_per_hour);
            score = itemView.findViewById(R.id.text_score);
            status = itemView.findViewById(R.id.text_status);
            scoreCircle = itemView.findViewById(R.id.score_badge);
        }
    }
}

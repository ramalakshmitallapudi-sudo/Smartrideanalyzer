package com.smartride.analyzer.core;

import com.smartride.analyzer.model.RideOffer;

import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.List;

/**
 * Holds every incoming ride offer, keeps them scored, and exposes sorted /
 * filtered views. Never removes an offer automatically except to keep the
 * queue from growing unbounded once an offer is long expired — it only stops
 * *considering* expired offers for "Best Current Offer", per the spec.
 */
public class RideQueueManager {

    private final List<RideOffer> offers = new ArrayList<>();
    private final RideAnalyzer analyzer;

    public RideQueueManager(RideAnalyzer analyzer) {
        this.analyzer = analyzer;
    }

    /** Adds a new offer to the queue and scores it immediately. */
    public void addOffer(RideOffer offer) {
        analyzer.analyze(offer);
        offers.add(0, offer); // newest first for display convenience
    }

    public void removeOffer(String offerId) {
        offers.removeIf(o -> o.getId().equals(offerId));
    }

    public void clear() {
        offers.clear();
    }

    /** Re-scores every offer — call when driver settings (fuel price/mileage) change. */
    public void rescoreAll() {
        analyzer.analyzeAll(offers);
    }

    public List<RideOffer> getAllOffers() {
        return Collections.unmodifiableList(offers);
    }

    /** Active = FRESH or EXPIRING (not EXPIRED), sorted by score descending. */
    public List<RideOffer> getActiveOffersSortedByScore(long nowMillis) {
        List<RideOffer> active = new ArrayList<>();
        for (RideOffer o : offers) {
            RideOffer.OfferStatus status = o.getStatus(nowMillis);
            if (status != RideOffer.OfferStatus.EXPIRED) {
                active.add(o);
            }
        }
        active.sort(Comparator.comparingInt(RideOffer::getScore).reversed());
        return active;
    }

    /** Returns the single highest-scoring active offer, or null if none. */
    public RideOffer getBestCurrentOffer(long nowMillis) {
        List<RideOffer> active = getActiveOffersSortedByScore(nowMillis);
        return active.isEmpty() ? null : active.get(0);
    }

    /** Drops offers that have been expired for a long time to prevent unbounded growth. */
    public void purgeStaleExpired(long nowMillis, long maxAgeMinutes) {
        offers.removeIf(o -> o.getAgeMinutes(nowMillis) > maxAgeMinutes);
    }

    public int size() {
        return offers.size();
    }
}

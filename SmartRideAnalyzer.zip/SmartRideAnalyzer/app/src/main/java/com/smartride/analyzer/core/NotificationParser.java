package com.smartride.analyzer.core;

import com.smartride.analyzer.model.RideOffer;

import java.util.Locale;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

/**
 * Extracts fare / pickup distance / trip distance / estimated time from the
 * raw text of a notification posted by a supported ride app.
 *
 * Real ride-app notifications change their wording over time and differ by
 * app version, so every pattern here is a best-effort starting point meant
 * to be tuned against real captured notification text, and new patterns
 * (or new apps) can be added without touching calling code.
 *
 * This class ONLY extracts data. It never touches the notification, never
 * dismisses it and never triggers any action inside the source app.
 */
public class NotificationParser {

    // Matches amounts like "₹320", "Rs 320", "INR 320.50"
    private static final Pattern FARE_PATTERN =
            Pattern.compile("(?:₹|Rs\\.?|INR)\\s?([0-9]+(?:\\.[0-9]+)?)", Pattern.CASE_INSENSITIVE);

    // Matches "1.2 km pickup", "pickup 1.2 km", "1.2km away"
    private static final Pattern PICKUP_PATTERN =
            Pattern.compile("([0-9]+(?:\\.[0-9]+)?)\\s?km\\s?(?:pickup|away|to pickup)", Pattern.CASE_INSENSITIVE);

    // Matches "trip 12 km", "12 km trip", "12.0km ride"
    private static final Pattern TRIP_DISTANCE_PATTERN =
            Pattern.compile("([0-9]+(?:\\.[0-9]+)?)\\s?km\\s?(?:trip|ride)", Pattern.CASE_INSENSITIVE);

    // Matches "25 min", "25 mins", "25 minutes"
    private static final Pattern TIME_PATTERN =
            Pattern.compile("([0-9]+)\\s?(?:min|mins|minutes)", Pattern.CASE_INSENSITIVE);

    /**
     * Attempts to parse an offer from a notification's package name + text.
     * Returns null if the source package isn't a supported app or if the
     * minimum required fields (fare) can't be found.
     */
    public RideOffer parse(String packageName, String notificationText, long postedAtMillis) {
        RideOffer.SourceApp app = identifyApp(packageName);
        if (app == null || notificationText == null) {
            return null;
        }

        Double fare = extractDouble(FARE_PATTERN, notificationText);
        if (fare == null) {
            return null; // Fare is the minimum viable field; without it, skip.
        }

        Double pickup = extractDouble(PICKUP_PATTERN, notificationText);
        Double tripDistance = extractDouble(TRIP_DISTANCE_PATTERN, notificationText);
        Double timeMinutes = extractDouble(TIME_PATTERN, notificationText);

        return new RideOffer(
                app,
                fare,
                pickup != null ? pickup : 0.0,
                tripDistance != null ? tripDistance : 0.0,
                timeMinutes != null ? timeMinutes : 0.0,
                postedAtMillis
        );
    }

    /** Maps a notification's source package name to a supported ride app. */
    public RideOffer.SourceApp identifyApp(String packageName) {
        if (packageName == null) return null;
        String pkg = packageName.toLowerCase(Locale.ROOT);
        if (pkg.contains("uber")) return RideOffer.SourceApp.UBER;
        if (pkg.contains("olacabs") || pkg.contains("ola.")) return RideOffer.SourceApp.OLA;
        if (pkg.contains("rapido")) return RideOffer.SourceApp.RAPIDO;
        return null;
    }

    private Double extractDouble(Pattern pattern, String text) {
        Matcher matcher = pattern.matcher(text);
        if (matcher.find()) {
            try {
                return Double.parseDouble(matcher.group(1));
            } catch (NumberFormatException e) {
                return null;
            }
        }
        return null;
    }
}

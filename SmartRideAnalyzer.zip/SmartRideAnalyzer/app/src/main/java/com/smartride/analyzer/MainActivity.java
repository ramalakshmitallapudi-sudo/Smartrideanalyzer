package com.smartride.analyzer;

import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.text.TextUtils;
import android.widget.Toast;

import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;

import com.smartride.analyzer.adapter.OfferAdapter;
import com.smartride.analyzer.core.CurrentTripManager;
import com.smartride.analyzer.core.DailyStatistics;
import com.smartride.analyzer.core.DriverSettings;
import com.smartride.analyzer.core.RideAnalyzer;
import com.smartride.analyzer.core.RideQueueManager;
import com.smartride.analyzer.databinding.ActivityMainBinding;
import com.smartride.analyzer.model.RideOffer;
import com.smartride.analyzer.service.RideOfferBridge;

import java.util.List;
import java.util.Locale;

public class MainActivity extends AppCompatActivity implements RideOfferBridge.Listener {

    private ActivityMainBinding binding;

    private DriverSettings driverSettings;
    private RideAnalyzer rideAnalyzer;
    private RideQueueManager queueManager;
    private CurrentTripManager tripManager;
    private DailyStatistics dailyStatistics;
    private OfferAdapter offerAdapter;

    // Refreshes offer statuses (FRESH/EXPIRING/EXPIRED) and Best Current Offer
    // periodically, since these are time-derived rather than event-driven.
    private final Handler refreshHandler = new Handler(Looper.getMainLooper());
    private final Runnable refreshRunnable = new Runnable() {
        @Override
        public void run() {
            refreshAllUi();
            refreshHandler.postDelayed(this, 15_000L);
        }
    };

    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        binding = ActivityMainBinding.inflate(getLayoutInflater());
        setContentView(binding.getRoot());

        driverSettings = new DriverSettings(this);
        dailyStatistics = new DailyStatistics(this);
        tripManager = new CurrentTripManager();
        rideAnalyzer = new RideAnalyzer(driverSettings.getFuelPricePerLitre(), driverSettings.getVehicleMileage());
        queueManager = new RideQueueManager(rideAnalyzer);

        setupSettingsSection();
        setupTripSection();
        setupOfferList();
        setupTestModeSection();

        loadSettingsIntoFields();
        refreshAllUi();
    }

    @Override
    protected void onResume() {
        super.onResume();
        RideOfferBridge.getInstance().addListener(this);
        refreshHandler.post(refreshRunnable);
    }

    @Override
    protected void onPause() {
        super.onPause();
        RideOfferBridge.getInstance().removeListener(this);
        refreshHandler.removeCallbacks(refreshRunnable);
    }

    // ---------------- DRIVER SETTINGS ----------------

    private void setupSettingsSection() {
        binding.btnSaveSettings.setOnClickListener(v -> {
            Float fuelPrice = parseFloatOrNull(binding.inputFuelPrice.getText());
            Float mileage = parseFloatOrNull(binding.inputMileage.getText());

            if (fuelPrice == null || fuelPrice <= 0) {
                Toast.makeText(this, "Enter a valid fuel price", Toast.LENGTH_SHORT).show();
                return;
            }
            if (mileage == null || mileage <= 0) {
                Toast.makeText(this, "Enter a valid mileage", Toast.LENGTH_SHORT).show();
                return;
            }

            driverSettings.setFuelPricePerLitre(fuelPrice);
            driverSettings.setVehicleMileage(mileage);
            rideAnalyzer = new RideAnalyzer(fuelPrice, mileage);
            queueManager = rebuildQueueWithNewAnalyzer();

            Toast.makeText(this, "Settings saved", Toast.LENGTH_SHORT).show();
            refreshAllUi();
        });
    }

    private void loadSettingsIntoFields() {
        binding.inputFuelPrice.setText(String.valueOf(driverSettings.getFuelPricePerLitre()));
        binding.inputMileage.setText(String.valueOf(driverSettings.getVehicleMileage()));
    }

    /** Rebuilds the queue manager around a new analyzer so all existing offers get rescored. */
    private RideQueueManager rebuildQueueWithNewAnalyzer() {
        RideQueueManager newManager = new RideQueueManager(rideAnalyzer);
        for (RideOffer offer : queueManager.getAllOffers()) {
            newManager.addOffer(offer);
        }
        return newManager;
    }

    // ---------------- CURRENT TRIP ----------------

    private void setupTripSection() {
        binding.btnStartTrip.setOnClickListener(v -> {
            Float minutes = parseFloatOrNull(binding.inputTripRemaining.getText());
            if (minutes == null || minutes < 0) {
                Toast.makeText(this, "Enter remaining minutes", Toast.LENGTH_SHORT).show();
                return;
            }
            tripManager.startTrip(minutes);
            refreshAllUi();
        });

        binding.btnEndTrip.setOnClickListener(v -> {
            tripManager.endTrip();
            refreshAllUi();
        });
    }

    // ---------------- OFFER LIST / BEST OFFER / AI ASSISTANT ----------------

    private void setupOfferList() {
        offerAdapter = new OfferAdapter(this::showAiExplanationFor);
        binding.recyclerOffers.setLayoutManager(new LinearLayoutManager(this));
        binding.recyclerOffers.setAdapter(offerAdapter);
    }

    private void showAiExplanationFor(RideOffer offer) {
        String reasons = TextUtils.join("\n• ", offer.getScoreReasons());
        String explanation = offer.getAppLabel() + " scored " + offer.getScore() + "/100:\n• " + reasons
                + "\n\nThis is an analysis only — you decide whether to accept or decline.";
        binding.textAiExplanation.setText(explanation);
    }

    // ---------------- MANUAL TEST MODE ----------------

    private void setupTestModeSection() {
        binding.btnAddUberTest.setOnClickListener(v -> {
            addOffer(RideOffer.SourceApp.UBER, 320, 1.2, 12, 25);
        });
        binding.btnAddOlaTest.setOnClickListener(v -> {
            addOffer(RideOffer.SourceApp.OLA, 280, 2.0, 10, 22);
        });
        binding.btnAddRapidoTest.setOnClickListener(v -> {
            addOffer(RideOffer.SourceApp.RAPIDO, 350, 0.8, 14, 28);
        });
        binding.btnAddAllTest.setOnClickListener(v -> {
            addOffer(RideOffer.SourceApp.UBER, 320, 1.2, 12, 25);
            addOffer(RideOffer.SourceApp.OLA, 280, 2.0, 10, 22);
            addOffer(RideOffer.SourceApp.RAPIDO, 350, 0.8, 14, 28);
        });
        binding.btnClearQueue.setOnClickListener(v -> {
            queueManager.clear();
            refreshAllUi();
        });
    }

    private void addOffer(RideOffer.SourceApp app, double fare, double pickup, double tripKm, double minutes) {
        RideOffer offer = new RideOffer(app, fare, pickup, tripKm, minutes, System.currentTimeMillis());
        queueManager.addOffer(offer);
        refreshAllUi();
    }

    // ---------------- NOTIFICATION BRIDGE (future feature) ----------------

    @Override
    public void onOfferPublished(RideOffer offer) {
        // Called from RideNotificationListenerService once real notification
        // parsing is wired up. Runs on the main thread via Handler post to be safe.
        runOnUiThread(() -> {
            queueManager.addOffer(offer);
            refreshAllUi();
            Toast.makeText(this, "New offer detected from " + offer.getAppLabel(), Toast.LENGTH_SHORT).show();
        });
    }

    // ---------------- SHARED REFRESH ----------------

    private void refreshAllUi() {
        long now = System.currentTimeMillis();

        // Trip intelligence
        binding.textTripIntelligence.setText(tripManager.getTripIntelligenceMessage());

        // Comparison list / Smart Ride Queue (active offers, best first)
        List<RideOffer> active = queueManager.getActiveOffersSortedByScore(now);
        offerAdapter.submitList(active);

        // Best Current Offer
        RideOffer best = queueManager.getBestCurrentOffer(now);
        if (best == null) {
            binding.textBestOfferSummary.setText(R.string.no_active_offers);
            binding.textBestOfferDetails.setText("");
        } else {
            binding.textBestOfferSummary.setText(String.format(Locale.US,
                    "%s — Score %d/100", best.getAppLabel(), best.getScore()));
            binding.textBestOfferDetails.setText(String.format(Locale.US,
                    "Fare ₹%.0f  •  Pickup %.1f km  •  Total %.1f km\nFuel ₹%.0f  •  Net ₹%.0f  •  ₹%.0f/hr",
                    best.getFare(), best.getPickupDistanceKm(), best.getTotalDistanceKm(),
                    best.getFuelCost(), best.getNetEarnings(), best.getEarningsPerHour()));
        }

        // Daily statistics
        binding.textDailyStats.setText(String.format(Locale.US,
                "Completed rides: %d\nGross earnings: ₹%.0f\nFuel cost: ₹%.0f\nNet earnings: ₹%.0f\nTotal distance: %.1f km\nNet earnings/hour: ₹%.0f/hr",
                dailyStatistics.getCompletedRides(), dailyStatistics.getGrossEarnings(),
                dailyStatistics.getFuelCost(), dailyStatistics.getNetEarnings(),
                dailyStatistics.getTotalDistance(), dailyStatistics.getNetEarningsPerHour()));

        // Purge very old expired offers so the queue doesn't grow forever.
        queueManager.purgeStaleExpired(now, 60);
    }

    private Float parseFloatOrNull(@Nullable CharSequence text) {
        if (text == null || text.length() == 0) return null;
        try {
            return Float.parseFloat(text.toString());
        } catch (NumberFormatException e) {
            return null;
        }
    }
}

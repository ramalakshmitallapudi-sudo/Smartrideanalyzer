package com.smartride.analyzer.model;

import java.util.UUID;

/**
 * Represents a single incoming ride offer from Uber, Ola, Rapido or another app.
 * Holds only raw offer data + calculated results. No offer in this class is ever
 * auto-accepted or auto-declined by the app.
 */
public class RideOffer {

    public enum SourceApp {
        UBER, OLA, RAPIDO, OTHER
    }

    public enum OfferStatus {
        FRESH,      // < 3 minutes old
        EXPIRING,   // 3 to < 5 minutes old
        EXPIRED     // >= 5 minutes old
    }

    private final String id;
    private final SourceApp app;
    private final double fare;              // rupees
    private final double pickupDistanceKm;
    private final double passengerDistanceKm;
    private final double estimatedTimeMinutes;
    private final long arrivalTimeMillis;

    // Populated by RideAnalyzer after calculation
    private double totalDistanceKm;
    private double fuelCost;
    private double netEarnings;
    private double earningsPerHour;
    private int score;
    private String[] scoreReasons = new String[0];

    public RideOffer(SourceApp app, double fare, double pickupDistanceKm,
                      double passengerDistanceKm, double estimatedTimeMinutes,
                      long arrivalTimeMillis) {
        this.id = UUID.randomUUID().toString();
        this.app = app;
        this.fare = fare;
        this.pickupDistanceKm = pickupDistanceKm;
        this.passengerDistanceKm = passengerDistanceKm;
        this.estimatedTimeMinutes = estimatedTimeMinutes;
        this.arrivalTimeMillis = arrivalTimeMillis;
    }

    /** Offer status is always derived live from arrival time — never stored/stale. */
    public OfferStatus getStatus(long nowMillis) {
        long ageMinutes = (nowMillis - arrivalTimeMillis) / 60000L;
        if (ageMinutes < 3) return OfferStatus.FRESH;
        if (ageMinutes < 5) return OfferStatus.EXPIRING;
        return OfferStatus.EXPIRED;
    }

    public long getAgeMinutes(long nowMillis) {
        return (nowMillis - arrivalTimeMillis) / 60000L;
    }

    // --- Getters ---
    public String getId() { return id; }
    public SourceApp getApp() { return app; }
    public double getFare() { return fare; }
    public double getPickupDistanceKm() { return pickupDistanceKm; }
    public double getPassengerDistanceKm() { return passengerDistanceKm; }
    public double getEstimatedTimeMinutes() { return estimatedTimeMinutes; }
    public long getArrivalTimeMillis() { return arrivalTimeMillis; }

    public double getTotalDistanceKm() { return totalDistanceKm; }
    public double getFuelCost() { return fuelCost; }
    public double getNetEarnings() { return netEarnings; }
    public double getEarningsPerHour() { return earningsPerHour; }
    public int getScore() { return score; }
    public String[] getScoreReasons() { return scoreReasons; }

    // --- Setters used only by RideAnalyzer ---
    public void setTotalDistanceKm(double v) { this.totalDistanceKm = v; }
    public void setFuelCost(double v) { this.fuelCost = v; }
    public void setNetEarnings(double v) { this.netEarnings = v; }
    public void setEarningsPerHour(double v) { this.earningsPerHour = v; }
    public void setScore(int v) { this.score = v; }
    public void setScoreReasons(String[] reasons) { this.scoreReasons = reasons; }

    public String getAppLabel() {
        switch (app) {
            case UBER: return "Uber";
            case OLA: return "Ola";
            case RAPIDO: return "Rapido";
            default: return "Other";
        }
    }
}

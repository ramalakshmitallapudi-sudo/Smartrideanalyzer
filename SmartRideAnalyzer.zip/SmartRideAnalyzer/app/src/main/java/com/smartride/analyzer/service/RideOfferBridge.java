package com.smartride.analyzer.service;

import com.smartride.analyzer.model.RideOffer;

import java.util.ArrayList;
import java.util.List;

/**
 * Lightweight in-process singleton that lets RideNotificationListenerService
 * (running in the system's notification-listener process context) hand a
 * newly parsed RideOffer to whichever screen is currently listening
 * (normally MainActivity), without needing a broadcast/bound-service setup
 * for this prototype stage.
 */
public class RideOfferBridge {

    public interface Listener {
        void onOfferPublished(RideOffer offer);
    }

    private static RideOfferBridge instance;

    public static synchronized RideOfferBridge getInstance() {
        if (instance == null) {
            instance = new RideOfferBridge();
        }
        return instance;
    }

    private final List<Listener> listeners = new ArrayList<>();

    private RideOfferBridge() { }

    public void addListener(Listener listener) {
        listeners.add(listener);
    }

    public void removeListener(Listener listener) {
        listeners.remove(listener);
    }

    public void publishOffer(RideOffer offer) {
        for (Listener l : new ArrayList<>(listeners)) {
            l.onOfferPublished(offer);
        }
    }
}

package com.smartride.analyzer.core;

/**
 * Tracks the driver's current in-progress passenger trip so the UI can
 * surface trip-intelligence messages while new offers keep arriving.
 * For the prototype the remaining time is set manually; a future version
 * can update it from live navigation/ETA data.
 */
public class CurrentTripManager {

    private boolean tripActive = false;
    private double remainingMinutes = 0;

    public void startTrip(double estimatedRemainingMinutes) {
        this.tripActive = true;
        this.remainingMinutes = estimatedRemainingMinutes;
    }

    public void updateRemainingMinutes(double remainingMinutes) {
        this.remainingMinutes = remainingMinutes;
    }

    public void endTrip() {
        this.tripActive = false;
        this.remainingMinutes = 0;
    }

    public boolean isTripActive() {
        return tripActive;
    }

    public double getRemainingMinutes() {
        return remainingMinutes;
    }

    /** Returns the driver-facing trip intelligence message for the current state. */
    public String getTripIntelligenceMessage() {
        if (!tripActive) {
            return "No current trip in progress.";
        }
        if (remainingMinutes > 5) {
            return "Current trip is still in progress. Incoming offers are being stored.";
        } else if (remainingMinutes > 2) {
            return "Trip is getting closer to completion. Review incoming offers.";
        } else {
            return "Trip is almost finished. Review queued offers.";
        }
    }
}
